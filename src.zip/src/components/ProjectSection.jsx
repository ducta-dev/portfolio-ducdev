import {
  useEffect,
  useState,
} from "react";

import {
  getProjects,
} from "../services/projectService";

import ProjectCard from "./ProjectCard";

export default function ProjectSection() {
  const [projects, setProjects] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {
    loadProjects();
  }, []);

  async function loadProjects() {
    try {
      const data =
        await getProjects();

      setProjects(data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <section
        className="
        py-28
        text-center
        "
      >
        Đang tải dự án...
      </section>
    );
  }

  return (
    <section
      id="projects"
      className="
      py-28
      "
    >
      <div
        className="
        max-w-7xl
        mx-auto
        px-8
        "
      >
        {/* Header */}

        <div
          className="
          flex
          justify-between
          items-end
          "
        >
          <div>

            <p
              className="
              text-red-500
              font-semibold
              "
            >
              DỰ ÁN NỔI BẬT
            </p>

            <h2
              className="
              mt-4
              text-5xl
              font-black
              "
            >
              Một số sản phẩm
              đã thực hiện
            </h2>

          </div>
        </div>

        {/* Empty */}

        {projects.length === 0 && (
          <div
            className="
            mt-20
            text-center
            text-slate-500
            "
          >
            Chưa có dự án nào
          </div>
        )}

        {/* Grid */}

        <div
          className="
          mt-16

          grid

          md:grid-cols-2

          lg:grid-cols-3

          gap-8
          "
        >
          {projects.map(
            (project) => (
            <ProjectCard
            key={project.id}
            project={project}
            />
            )
          )}
        </div>

      </div>
    </section>
  );
}