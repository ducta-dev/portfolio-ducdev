import { Link } from "react-router-dom";

export default function ProjectCard({ project }) {
  if (!project) return null;

  const cover =
    project.cover_image ||
    project.project_images?.[0]?.image_url ||
    "/placeholder.png";

  return (
    <Link to={`/project/${project.slug}`}>
      <div
        className="
        rounded-[32px]
        overflow-hidden

        bg-white

        border
        border-slate-200

        hover:-translate-y-2
        hover:shadow-2xl

        transition

        duration-300
        "
      >
        <div className="aspect-[16/10] overflow-hidden">

          <img
            src={cover}
            alt={project.title}
            className="
            w-full
            h-full
            object-cover

            hover:scale-105
            transition
            duration-700
            "
          />

        </div>

        <div className="p-7">

          <h3
            className="
            text-3xl
            font-black
            text-slate-900
            "
          >
            {project.title}
          </h3>

          <p
            className="
            mt-4
            text-slate-600
            line-clamp-3
            "
          >
            {project.description}
          </p>

          <div
            className="
            mt-8
            flex
            justify-between
            "
          >
            <span
              className="
              text-red-500
              font-bold
              "
            >
              {project.price}
            </span>

            <span className="text-blue-600">
              {project.duration}
            </span>

          </div>

        </div>

      </div>
    </Link>
  );
}