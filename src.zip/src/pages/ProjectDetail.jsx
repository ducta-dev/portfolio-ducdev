import { useEffect, useState } from "react";

import {
  useNavigate,
  useParams,
} from "react-router-dom";

import {
  getProjectBySlug,
} from "../services/projectService";

export default function ProjectDetail() {
  const { slug } = useParams();

  const navigate = useNavigate();

  const [project, setProject] =
    useState(null);

  const [loading, setLoading] =
    useState(true);

  const [selectedImage, setSelectedImage] =
    useState(null);

  useEffect(() => {
    loadData();
  }, [slug]);

  async function loadData() {
    try {
      setLoading(true);

      const data =
        await getProjectBySlug(slug);

      setProject(data);

    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center bg-[#070B16] text-white">
        Đang tải...
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen grid place-items-center bg-[#070B16] text-white">
        Không tìm thấy dự án
      </div>
    );
  }

  const gallery =
    project.project_images || [];

  let features = [];

  if (Array.isArray(project.features)) {
    features = project.features;
  } else if (
    typeof project.features === "string"
  ) {
    features = project.features
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);
  }

  const embedVideo =
    project.video?.includes("watch?v=")
      ? project.video.replace(
          "watch?v=",
          "embed/"
        )
      : project.video;

  return (
    <>
      <main
        className="
        min-h-screen
        bg-[#070B16]
        text-white
        "
      >
        <section
          className="
          max-w-7xl
          mx-auto
          px-8
          py-16
          "
        >
          <button
            onClick={() => navigate(-1)}
            className="
            mb-10
            px-5
            py-3
            rounded-xl
            bg-white/10
            hover:bg-white/20
            transition
            "
          >
            ← Quay lại
          </button>

          <div
            className="
            grid
            lg:grid-cols-2
            gap-12
            items-center
            "
          >
            <div>
              {project.cover_image && (
                <img
                  src={project.cover_image}
                  alt={project.title}
                  className="
                  w-full
                  h-[520px]
                  object-cover
                  rounded-[36px]
                  shadow-2xl
                  "
                />
              )}
            </div>

            <div>
              <p
                className="
                inline-flex
                px-4
                py-2
                rounded-full
                bg-white/10
                text-sm
                text-slate-300
                "
              >
                Dự án nổi bật
              </p>

              <h1
                className="
                mt-6
                text-6xl
                font-black
                leading-tight
                bg-gradient-to-r
                from-red-500
                to-blue-500
                bg-clip-text
                text-transparent
                "
              >
                {project.title}
              </h1>

              <p
                className="
                mt-6
                text-xl
                leading-8
                text-slate-300
                "
              >
                {project.description}
              </p>

              <div
                className="
                mt-10
                flex
                flex-wrap
                gap-5
                "
              >
                {project.price && (
                  <div
                    className="
                    rounded-3xl
                    bg-white/10
                    border
                    border-white/10
                    p-6
                    min-w-[180px]
                    "
                  >
                    <div className="text-slate-400">
                      Giá tham khảo
                    </div>

                    <div
                      className="
                      mt-2
                      text-2xl
                      font-black
                      "
                    >
                      {project.price}
                    </div>
                  </div>
                )}

                {project.duration && (
                  <div
                    className="
                    rounded-3xl
                    bg-white/10
                    border
                    border-white/10
                    p-6
                    min-w-[180px]
                    "
                  >
                    <div className="text-slate-400">
                      Thời gian
                    </div>

                    <div
                      className="
                      mt-2
                      text-2xl
                      font-black
                      "
                    >
                      {project.duration}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {features.length > 0 && (
            <section className="mt-24">
              <h2 className="text-4xl font-black">
                Tính năng
              </h2>

              <div
                className="
                mt-8
                grid
                md:grid-cols-2
                lg:grid-cols-4
                gap-6
                "
              >
                {features.map((item, index) => (
                  <div
                    key={index}
                    className="
                    rounded-3xl
                    bg-white/10
                    border
                    border-white/10
                    p-6
                    "
                  >
                    ✅ {item}
                  </div>
                ))}
              </div>
            </section>
          )}

          {gallery.length > 0 && (
            <section className="mt-24">

              <h2 className="text-4xl font-black">
                Gallery
              </h2>

              <div
                className="
                mt-8
                grid
                md:grid-cols-2
                lg:grid-cols-3
                gap-6
                "
              >
                {gallery.map((item) => (
                  <img
                    key={item.id}
                    src={item.image_url}
                    alt=""
                    onClick={() =>
                      setSelectedImage(
                        item.image_url
                      )
                    }
                    className="
                    w-full
                    h-[280px]
                    object-cover
                    rounded-3xl

                    cursor-pointer

                    hover:scale-[1.03]

                    transition
                    duration-300
                    "
                  />
                ))}
              </div>

            </section>
          )}

          {embedVideo && (
            <section className="mt-24">
              <h2 className="text-4xl font-black">
                Demo Video
              </h2>

              <iframe
                src={embedVideo}
                title={project.title}
                allowFullScreen
                className="
                mt-8
                w-full
                h-[650px]
                rounded-3xl
                bg-black
                "
              />
            </section>
          )}
        </section>
      </main>

      {/* IMAGE MODAL */}

      {selectedImage && (

        <div
          onClick={() =>
            setSelectedImage(null)
          }
          className="
          fixed
          inset-0
          z-50

          bg-black/90

          flex
          items-center
          justify-center

          p-8
          "
        >

          <button
            onClick={() =>
              setSelectedImage(null)
            }
            className="
            absolute
            top-6
            right-6

            text-white
            text-5xl
            "
          >
            ×
          </button>

          <img
            src={selectedImage}
            alt=""
            className="
            max-w-full
            max-h-full

            rounded-3xl

            shadow-2xl
            "
          />

        </div>

      )}
    </>
  );
}