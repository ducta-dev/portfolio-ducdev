import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import ProjectSection from "../components/ProjectSection";

export default function Home() {
  return (
    <>
      <Navbar />

      <Hero />

      <ProjectSection />
    </>
  );
}