import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import supabase from "../services/supabase";

import {
  getProjects,
} from "../services/projectService";

import {
  uploadGallery,
  saveGallery,
} from "../services/galleryService";

import {
  logout,
} from "../services/authService";

import AdminTable from "../components/AdminTable";

import slugify from "../utils/slugify";

export default function Admin() {

const navigate =
useNavigate();

const [
projects,
setProjects
] =
useState([]);

const [
loading,
setLoading
] =
useState(false);

const [
editing,
setEditing
] =
useState(null);

const [
files,
setFiles
] =
useState([]);

const [
preview,
setPreview
] =
useState([]);

const [
form,
setForm
] =
useState({

title:"",
slug:"",
description:"",
cover_image:"",
video:"",
price:"",
duration:"",

});

useEffect(()=>{

load();

},[]);

async function load(){

const data =
await getProjects();

setProjects(
data || []
);

}

function reset(){

setEditing(
null
);

setFiles([]);

setPreview([]);

setForm({

title:"",
slug:"",
description:"",
cover_image:"",
video:"",
price:"",
duration:"",

});

}

function updateField(
e
){

const {
name,
value
}
=
e.target;

if(
name==="title"
){

setForm(

prev=>({

...prev,

title:value,

slug:
slugify(
value
)

})

);

return;

}

setForm(

prev=>({

...prev,

[name]:
value

})

);

}

function selectFiles(
e
){

const selected=

Array.from(
e.target.files
);

setFiles(
selected
);

setPreview(

selected.map(

f=>

URL.createObjectURL(
f
)

)

);

}

function edit(
project
){

setEditing(
project.id
);

setForm({

title:
project.title ||

"",

slug:
project.slug ||

"",

description:
project.description ||

"",

cover_image:
project.cover_image ||

"",

video:
project.video ||

"",

price:
project.price ||

"",

duration:
project.duration ||

"",

});

setPreview(

project.project_images

?.map(

i=>

i.image_url

)

||

[]

);

window.scrollTo({

top:0,

behavior:
"smooth"

});

}

async function submit(
e
){

e.preventDefault();

try{

setLoading(
true
);

let cover=

form.cover_image;

let gallery=[];

if(
files.length
){

gallery=

await uploadGallery(
files
);

cover=
gallery[0];

}

const payload={

title:
form.title,

slug:
form.slug,

description:
form.description,

cover_image:
cover,

video:
form.video,

price:
form.price,

duration:
form.duration,

};

let projectId=
editing;

if(
editing
){

const {
error
}

=

await supabase

.from(
"projects"
)

.update(
payload
)

.eq(
"id",
editing
);

if(
error
){

throw error;

}

}else{

const{

data,
error

}

=

await supabase

.from(
"projects"
)

.insert([
payload
])

.select();

if(
error
){

throw error;

}

projectId=
data?.[0]?.id;

}

if(
projectId &&
gallery.length
){

await saveGallery(

projectId,

gallery

);

}

alert(

editing

?

"Đã cập nhật"

:

"Đã thêm"

);

reset();

load();

}catch(
err
){

console.log(
err
);

alert(
err.message
);

}

finally{

setLoading(
false
);

}

}

async function signOut(){

await logout();

navigate(
"/login"
);

}

return(

<section
className="
max-w-6xl
mx-auto
px-8
py-20
"
>

<div
className="
flex
justify-between
mb-10
"
>

<h1
className="
text-6xl
font-black
"
>
Admin
</h1>

<button
onClick={
signOut
}
>
Đăng xuất
</button>

</div>

<form
onSubmit={
submit
}
className="
space-y-5
"
>

<input
name="title"
value={form.title}
onChange={updateField}
placeholder="Tên dự án"
className="w-full p-4 border rounded-2xl"
/>

<input
value={form.slug}
readOnly
className="w-full p-4 rounded-2xl bg-gray-100"
/>

<textarea
rows="5"
name="description"
value={form.description}
onChange={updateField}
className="w-full p-4 border rounded-2xl"
/>

<input
name="video"
value={form.video}
onChange={updateField}
placeholder="Video URL"
className="w-full p-4 border rounded-2xl"
/>

<input
name="price"
value={form.price}
onChange={updateField}
placeholder="Giá"
className="w-full p-4 border rounded-2xl"
/>

<input
name="duration"
value={form.duration}
onChange={updateField}
placeholder="Thời gian"
className="w-full p-4 border rounded-2xl"
/>

<input
type="file"
multiple
accept="image/*"
onChange={selectFiles}
/>

<div
className="
grid
grid-cols-2
gap-4
"
>

{

preview.map(

img=>(

<img

key={img}

src={img}

className="
rounded-3xl
"

/>

)

)

}

</div>

<button
className="
bg-black
text-white
px-8
py-4
rounded-2xl
"
disabled={
loading
}
>

{

loading

?

"Đang lưu..."

:

editing

?

"Cập nhật"

:

"Thêm"

}

</button>

</form>

<div
className="
mt-20
"
>

<AdminTable

projects={
projects
}

edit={
edit
}

reload={
load
}

/>

</div>

</section>

);

}