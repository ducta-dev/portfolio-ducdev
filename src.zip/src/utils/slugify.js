export default function slugify(
  text
) {
  return text
    .toLowerCase()

    .normalize(
      "NFD"
    )

    .replace(
      /[\u0300-\u036f]/g,
      ""
    )

    .replace(
      /đ/g,
      "d"
    )

    .replace(
      /\s+/g,
      "-"
    )

    .replace(
      /[^a-z0-9-]/g,
      ""
    )

    .replace(
      /-+/g,
      "-"
    )

    .trim();
}